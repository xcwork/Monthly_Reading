# archive bfs/bfs.cpp and bfs/bfs.h into bfs.tar.gz

tar -czvf asst5.tar.gz bfs/bfs.cpp bfs/bfs.h