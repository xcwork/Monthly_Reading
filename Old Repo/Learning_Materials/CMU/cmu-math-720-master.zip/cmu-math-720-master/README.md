
These are brief notes for [Gautam Iyer's](http://www.math.cmu.edu/~gautam) graduate measure theory course:

* [Eugene Choi](mailto:choideugene@gmail.com) typed notes for [Fall 2013](http://www.math.cmu.edu/~gautam/teaching/2013-14/720-measure/).

* [Adam Gutter](mailto:agutter@andrew.cmu.edu) typed notes for [Fall 2014](http://www.math.cmu.edu/~gautam/teaching/2014-15/720-measure).

* [Gautam Iyer](http://www.math.cmu.edu/~gautam) taught remotely in [Fall 2020](http://www.math.cmu.edu/~gautam/sj/teaching/2020-21/720-measure/) and typed minimal slides containing only theorem statements and definitions. A PDF of these is [here](http://www.math.cmu.edu/~gautam/sj/teaching/2020-21/720-measure/pdfs/measure.pdf), and an annotated version with hand-written proofs is [here](http://www.math.cmu.edu/~gautam/sj/teaching/2020-21/720-measure/pdfs/measure-ann.pdf).

If you use these notes and find typos, or want to change them in any way, please consider contributing your changes back here.
