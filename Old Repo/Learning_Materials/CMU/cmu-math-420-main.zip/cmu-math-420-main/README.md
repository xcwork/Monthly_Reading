
These are brief notes for [Gautam Iyer's](http://www.math.cmu.edu/~gautam) undergraduate continuous time finance course.
These slides only contain statements and definitions.
During class I filled in the proofs and provided explanations.
A PDF of these notes and other resources can be found on the class [https://www.math.cmu.edu/~gautam/sj/teaching/2021-22/420-cts-time-finance/](website)

If you use these notes and find typos, or want to change them in any way, please consider contributing your changes back here.
